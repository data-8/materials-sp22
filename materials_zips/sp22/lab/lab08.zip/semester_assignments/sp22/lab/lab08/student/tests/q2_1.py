test = {   'name': 'q2_1',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> np.random.seed(8)\n>>> np.round(one_sample_mean(salaries, 'salary', 100), 3) == 76699.829\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
