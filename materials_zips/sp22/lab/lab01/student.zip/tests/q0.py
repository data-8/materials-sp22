test = {   'name': 'q0',
    'points': None,
    'suites': [{'cases': [{'code': '>>> secret_word == "welcome"\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
