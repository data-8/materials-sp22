test = {   'name': 'q121',
    'points': None,
    'suites': [{'cases': [{'code': '>>> abs(difference) == 30 or abs(difference) == 30.0\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
