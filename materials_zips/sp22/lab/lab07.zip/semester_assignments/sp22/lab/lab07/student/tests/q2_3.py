test = {   'name': 'q2_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> means.num_rows\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(min(means.column("star baker awards mean")), 2) == 0.65\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(max(means.column("star baker awards mean")), 2) == 1.5\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
