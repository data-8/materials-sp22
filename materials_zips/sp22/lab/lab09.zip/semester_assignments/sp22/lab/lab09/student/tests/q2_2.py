test = {   'name': 'q2_2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 33 < intercept < 34\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> np.round(intercept, 3) == 33.474\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
