test = {   'name': 'q2_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> (slope*13 - 100)/98 <= 0.5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(slope, 4) == 10.7296 # Make sure you are plugging in the SD_x and SD_y in the correct spots!\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
