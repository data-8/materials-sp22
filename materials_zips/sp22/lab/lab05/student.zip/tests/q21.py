test = {   'name': 'q21',
    'points': None,
    'suites': [{'cases': [{'code': '>>> longer_than_five == 35453\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
