test = {   'name': 'q12',
    'points': None,
    'suites': [{'cases': [{'code': ">>> say_please == 'More please'\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
