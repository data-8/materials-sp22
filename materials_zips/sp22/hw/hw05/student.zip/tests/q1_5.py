test = {   'name': 'q1_5',
    'points': [5, 5],
    'suites': [   {   'cases': [   {'code': '>>> is_big_win(final_scores.row(2)) is True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Make sure big_wins is an array.\n>>> import numpy as np\n>>> type(big_wins) == np.ndarray\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
