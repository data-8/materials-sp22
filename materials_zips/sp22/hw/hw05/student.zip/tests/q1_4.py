test = {   'name': 'q1_4',
    'points': [0, 0],
    'suites': [   {   'cases': [{'code': '>>> 0 <= cal_wins <= 10\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> 0 <= cal_losses <= 10\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
