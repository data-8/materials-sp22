test = {   'name': 'q1_3',
    'points': [2, 2],
    'suites': [   {   'cases': [   {'code': ">>> with_commas == 'Eats, Shoots, and Leaves'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> without_commas == 'Eats Shoots and Leaves'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
