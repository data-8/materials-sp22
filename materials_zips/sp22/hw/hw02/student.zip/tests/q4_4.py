test = {   'name': 'q4_4',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 15 <= average_error <= 25\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
