test = {   'name': 'q5_3',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> all_different in {True, False}\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
