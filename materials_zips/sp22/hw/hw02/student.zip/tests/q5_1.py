test = {   'name': 'q5_1',
    'points': [4],
    'suites': [   {   'cases': [{'code': '>>> fruits.sort(0)\nfruit name | count\napple      | 4\norange     | 3\npineapple  | 3', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
