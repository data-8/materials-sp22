test = {   'name': 'q5_6',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': ">>> # If you're stuck, here's a hint: You want to multiply the count\n"
                                               '>>> # sold in each box by the per-item price of fruits in that box.\n'
                                               '>>> # You can use elementwise multiplication for that.\n'
                                               '>>> # Then you want the sum of those products.  Use sum().\n'
                                               '>>> 50 <= total_revenue <= 150\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
