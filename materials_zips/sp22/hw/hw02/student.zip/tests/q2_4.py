test = {   'name': 'q2_4',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> most_recent_birth_year == 1917\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
