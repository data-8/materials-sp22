test = {   'name': 'q3_1',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> first_product > 0, second_product < 0, third_product > 0, fourth_product > 0\n(True, True, True, True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
