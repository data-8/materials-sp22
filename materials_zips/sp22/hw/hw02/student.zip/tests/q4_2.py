test = {   'name': 'q4_2',
    'points': [0, 0],
    'suites': [   {   'cases': [   {   'code': '>>> # Hint: If you are getting 47 as your answer, you might be computing the biggest change \n'
                                               '>>> # rather than the biggest decrease!\n'
                                               '>>> biggest_decrease == 47\n'
                                               'False',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> # Hint: biggest decrease is above 30, but not 47.\n>>> 30 <= biggest_decrease < 47\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
