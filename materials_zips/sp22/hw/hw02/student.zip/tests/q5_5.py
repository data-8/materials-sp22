test = {   'name': 'q5_5',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': ">>> # We're asking for the number of *pieces* of fruit, not the\n"
                                               '>>> # number of kinds of fruit or the number of boxes from which\n'
                                               '>>> # there were sales.\n'
                                               '>>> total_fruits_sold > 10\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
