test = {   'name': 'q3_11',
    'points': [0, 0, 0],
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(p_val) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= p_val <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(conclusion) == str\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
