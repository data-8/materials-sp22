test = {   'name': 'q3_2',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> import numpy as np\n>>> type(avg_male_vs_female) in set([bool, np.bool_])\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
