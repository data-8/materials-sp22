test = {   'name': 'q3_6',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(observed_statistic_ab) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> observed_statistic_ab >= 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
