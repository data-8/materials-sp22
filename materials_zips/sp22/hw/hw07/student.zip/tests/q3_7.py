test = {   'name': 'q3_7',
    'points': [0, 0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(original_with_shuffled_labels) == Table\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> original_with_shuffled_labels.labels == ("Gender", "Age", "Shuffled Label")\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> original_with_shuffled_labels.num_rows == 500\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
