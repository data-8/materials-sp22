test = {   'name': 'q1_9',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(correct_doctor) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> any((correct_doctor == x for x in (1,2)))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
