test = {   'name': 'q1_2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> # Make sure you are using the correct table! \n>>> yelp_and_google.num_rows == 212\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
