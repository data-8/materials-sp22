test = {   'name': 'q1_5',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Your answer should be a string\n>>> type(best_california_burrito) == str\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
