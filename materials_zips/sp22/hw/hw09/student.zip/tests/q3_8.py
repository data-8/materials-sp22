test = {   'name': 'q3_8',
    'points': [1],
    'suites': [{'cases': [{'code': '>>> larger_sample_size > michelle_sample_size\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
