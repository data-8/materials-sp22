test = {   'name': 'q2_3',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 700 <= smallest_num <= 800\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
