test = {   'name': 'q3_6',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> type(michelle_sample_size) == int\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
