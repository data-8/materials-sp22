test = {   'name': 'q4_1',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Make sure secret_word is assigned to a string!\n>>> type(secret_word) == str\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
