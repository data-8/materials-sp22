test = {   'name': 'q1_6',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': '>>> pter_over_time.take(0)\nDate       | NEI     | NEI-PTER | Year | PTER\n1994-01-01 | 10.0974 | 11.172   | 1994 | 1.0746',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
