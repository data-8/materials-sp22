test = {   'name': 'q4_1',
    'points': [0, 1],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you assign histogram_column_x to either 1 or 2!\n>>> type(histogram_column_x) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> histogram_column_x == 1 or histogram_column_x == 2 or histogram_column_x == 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
