test = {   'name': 'q3_5',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Make sure boston_median_bin is assigned to 1, 2, 3, or 4.\n>>> 1 <= boston_median_bin <= 4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
