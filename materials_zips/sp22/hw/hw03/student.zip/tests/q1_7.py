test = {   'name': 'q1_7',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> highPTER == True or highPTER == False\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
