test = {   'name': 'q3_4',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> boston_under_15 >= 0 and boston_under_15 <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> manila_under_15 >= 0 and manila_under_15 <= 100\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
