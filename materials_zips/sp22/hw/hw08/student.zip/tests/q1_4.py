test = {   'name': 'q1_4',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> type(one_resampled_difference(votes)) in set([float, np.float64]) \nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
