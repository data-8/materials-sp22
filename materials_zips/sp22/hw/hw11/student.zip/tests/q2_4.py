test = {   'name': 'q2_4',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> len(predictions_for_eight) == regression_lines.num_rows\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
