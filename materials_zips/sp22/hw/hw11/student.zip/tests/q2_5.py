test = {   'name': 'q2_5',
    'points': [0, 0],
    'suites': [   {   'cases': [{'code': '>>> lower_bound > 5\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> upper_bound < 6.5\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
