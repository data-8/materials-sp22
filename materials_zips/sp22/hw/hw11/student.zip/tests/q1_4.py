test = {   'name': 'q1_4',
    'points': None,
    'suites': [{'cases': [{'code': '>>> len(resampled_slopes) == 1000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
