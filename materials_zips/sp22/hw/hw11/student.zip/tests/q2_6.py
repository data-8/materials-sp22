test = {   'name': 'q2_6',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> type(plover_statements) == np.ndarray\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
