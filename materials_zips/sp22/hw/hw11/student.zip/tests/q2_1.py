test = {   'name': 'q2_1',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> type(egg_weight_eight) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
