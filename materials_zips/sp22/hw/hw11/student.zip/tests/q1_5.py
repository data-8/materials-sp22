test = {   'name': 'q1_5',
    'points': [0, 0],
    'suites': [   {   'cases': [{'code': '>>> lower_end > 0\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> upper_end < 4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
