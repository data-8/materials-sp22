test = {'name': 'q7_6', 'points': [4], 'suites': [{'cases': [{'code': '>>> drops == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
