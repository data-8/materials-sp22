test = {'name': 'q7_2', 'points': [4], 'suites': [{'cases': [{'code': '>>> grades == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
