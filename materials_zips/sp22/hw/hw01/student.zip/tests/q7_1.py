test = {'name': 'q7_1', 'points': [4], 'suites': [{'cases': [{'code': '>>> contact == 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
