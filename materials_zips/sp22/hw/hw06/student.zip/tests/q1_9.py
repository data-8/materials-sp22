test = {   'name': 'q1_9',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> len(all_gains_split) == 10000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
