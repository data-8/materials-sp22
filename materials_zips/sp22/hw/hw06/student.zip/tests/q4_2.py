test = {   'name': 'q4_2',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you are setting statistic_choice to an int\n>>> type(statistic_choice) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # statistic_choice should be assigned to either 1, 2 or 3.\n>>> 1 <= statistic_choice <= 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
