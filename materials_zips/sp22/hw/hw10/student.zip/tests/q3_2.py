test = {   'name': 'q3_2',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 4 <= spread_5_outcome_average <= 6\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
