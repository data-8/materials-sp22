test = {   'name': 'q3_3',
    'points': [0, 0],
    'suites': [   {   'cases': [{'code': '>>> 0 <= spread_slope < 1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> spread_intercept > 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
