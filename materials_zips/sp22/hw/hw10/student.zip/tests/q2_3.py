test = {   'name': 'q2_3',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 0 < eth_predictor(10) < 100\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
