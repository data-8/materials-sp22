test = {   'name': 'q1_7',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 100 <= triple_record_vert_est <= 200\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
