test = {   'name': 'q1_4',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> type(first_test) == str or type(first_test) == np.str_\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
