test = {   'name': 'q1_2',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> # Double check that you have the correct number of rows for the `train` table.\n>>> train.num_rows == 75\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Double check that you have the correct number of rows for the `test` table.\n>>> test.num_rows == 25\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
