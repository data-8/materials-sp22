test = {   'name': 'q1_6',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> # `k` should be an int\n>>> type(k) == int\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
