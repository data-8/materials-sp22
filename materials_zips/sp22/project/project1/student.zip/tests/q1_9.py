test = {   'name': 'q1_9',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> # Please use a list of integers from 1 to 6\n>>> all(x in range(1, 7) for x in set(fertility_statements))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
