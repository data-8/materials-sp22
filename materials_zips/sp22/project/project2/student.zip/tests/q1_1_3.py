test = {   'name': 'q1_1_3',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(num_unique_cites) in set([int, np.int32, np.int64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Make sure that num_unique_cities is greater than zero!\n>>> num_unique_cites > 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
