test = {   'name': 'q1_1_5',
    'points': [0, 0, 1],
    'suites': [   {   'cases': [   {'code': '>>> len(cities.labels) == 8\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> cities.labels[-1] == "Region"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> cities.row(0).item('Region') == 'Northwest'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
