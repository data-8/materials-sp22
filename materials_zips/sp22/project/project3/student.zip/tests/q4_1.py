test = {   'name': 'q4_1',
    'points': [0, 3],
    'suites': [   {   'cases': [   {'code': '>>> len(new_features) <= 5 # You have too many features\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> another_classifier(test_new.row(0)) in ["comedy", "thriller"] \nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
